classdef UHPCPredictApp < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                   matlab.ui.Figure
        InputPanel                 matlab.ui.container.Panel
        CuringPanel                matlab.ui.container.Panel
        OutputPanel                matlab.ui.container.Panel
        PredictButton              matlab.ui.control.Button
        CementEditField            matlab.ui.control.NumericEditField
        SilicaFumeEditField        matlab.ui.control.NumericEditField
        SlagEditField              matlab.ui.control.NumericEditField
        FlyAshEditField            matlab.ui.control.NumericEditField
        QuartzPowderEditField      matlab.ui.control.NumericEditField
        AshPowderEditField         matlab.ui.control.NumericEditField
        NanoSilicaEditField        matlab.ui.control.NumericEditField
        WaterEditField             matlab.ui.control.NumericEditField
        FineAggregateEditField     matlab.ui.control.NumericEditField
        CoarseAggregateEditField   matlab.ui.control.NumericEditField
        FiberEditField             matlab.ui.control.NumericEditField
        WaterReducerEditField      matlab.ui.control.NumericEditField
        TempEditField              matlab.ui.control.NumericEditField
        HumidityEditField          matlab.ui.control.NumericEditField
        CuringTimeEditField        matlab.ui.control.NumericEditField
        ResultLabel                matlab.ui.control.Label
    end

    methods (Access = private)

        % Button pushed function: PredictButton
        function onPredictButtonPushed(app, event)
            % 获取用户输入数据
            data = [
                app.CementEditField.Value, ...
                app.SilicaFumeEditField.Value, ...
                app.SlagEditField.Value, ...
                app.FlyAshEditField.Value, ...
                app.QuartzPowderEditField.Value, ...
                app.AshPowderEditField.Value, ...
                app.NanoSilicaEditField.Value, ...
                app.WaterEditField.Value, ...
                app.FineAggregateEditField.Value, ...
                app.CoarseAggregateEditField.Value, ...
                app.FiberEditField.Value, ...
                app.WaterReducerEditField.Value, ...
                app.TempEditField.Value, ...
                app.HumidityEditField.Value, ...
                app.CuringTimeEditField.Value
            ];

            % 导入训练好的模型并进行预测
            try
                % 模型函数名为 myNeuralNetworkFunction_1
                predictedStrength = myNeuralNetworkFunction_1(data);

                % 显示预测结果
                app.ResultLabel.Text = ['The compressive strength of UHPC is：', num2str(predictedStrength), ' MPa'];
            catch ME
                % 如果模型调用失败，显示错误信息
                app.ResultLabel.Text = ['预测失败: ', ME.message];
            end
        end
    end

    methods (Access = private)

        % Create UI components
        function createComponents(app)

            % Create UIFigure
            app.UIFigure = uifigure('Position', [100 100 800 600], 'Name', 'UHPC compressive strength prediction software');

            % Create InputPanel
            app.InputPanel = uipanel(app.UIFigure, 'Title', 'UHPC material parameters (unit: kg/m^3)', ...
                'Position', [20 300 580 300]);

            % Create NumericEditFields and Labels for all inputs
            createLabeledField(app.InputPanel, '1.R:', 20, 200, app, 'CementEditField');
            createLabeledField(app.InputPanel, '2.SF:', 20, 160, app, 'SilicaFumeEditField');
            createLabeledField(app.InputPanel, '3.S:', 20, 120, app, 'SlagEditField');
            createLabeledField(app.InputPanel, '4.FA:', 20, 80, app, 'FlyAshEditField');
            createLabeledField(app.InputPanel, '5.QP:', 200, 200, app, 'QuartzPowderEditField');
            createLabeledField(app.InputPanel, '6.LP:', 200, 160, app, 'AshPowderEditField');
            createLabeledField(app.InputPanel, '7.NS:', 200, 120, app, 'NanoSilicaEditField');
            createLabeledField(app.InputPanel, '8.W:', 200, 80, app, 'WaterEditField');
            createLabeledField(app.InputPanel, '9.Sand:', 380, 200, app, 'FineAggregateEditField');
            createLabeledField(app.InputPanel, '10.Gravel:', 380, 160, app, 'CoarseAggregateEditField');
            createLabeledField(app.InputPanel, '11.Fi:', 380, 120, app, 'FiberEditField');
            createLabeledField(app.InputPanel, '12.SP:', 380, 80, app, 'WaterReducerEditField');

            % Create CuringPanel
            app.CuringPanel = uipanel(app.UIFigure, 'Title', 'Curing conditions for UHPC', ...
                'Position', [20 200 580 90]);

            % Create NumericEditFields and Labels for curing conditions
            createLabeledField(app.CuringPanel, '13.RH (%):', 20, 30, app, 'TempEditField');
            createLabeledField(app.CuringPanel, '14.T (°C):', 200, 30, app, 'HumidityEditField');
            createLabeledField(app.CuringPanel, '15.Age (D):', 380, 30, app, 'CuringTimeEditField');

            % Create OutputPanel
            app.OutputPanel = uipanel(app.UIFigure, 'Title', 'Compressive strength of UHPC', ...
                'Position', [20 20 580 160]);

            % Create PredictButton
            app.PredictButton = uibutton(app.OutputPanel, 'push', 'Text', 'Predicting', ...
                'Position', [450 20 100 40], ...
                'ButtonPushedFcn', @(btn, event) onPredictButtonPushed(app));

            % Create ResultLabel
            app.ResultLabel = uilabel(app.OutputPanel, ...
                'Position', [40 60 580 40], ...
                'Text', 'The compressive strength of UHPC is: ', ...
                'HorizontalAlignment', 'left');
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = UHPCPredictApp
            % Create UI components
            createComponents(app)
        end

        % Code that executes before app deletion
        function delete(app)
            % Delete UIFigure
            delete(app.UIFigure)
        end
    end
end

function createLabeledField(parentPanel, labelText, x, y, app, fieldName)
    % Create a label and numeric edit field pair
    uilabel(parentPanel, ...
        'Position', [x, y, 60, 22], ...
        'Text', labelText, ...
        'HorizontalAlignment', 'right');
    app.(fieldName) = uieditfield(parentPanel, 'numeric', ...
        'Position', [x + 70, y, 100, 22]);
end
