feature_index = 15; % 选择第一个特征
x_values = linspace(min(x(feature_index, :)), max(x(feature_index, :)), 100); % 生成 100 个点

pdp_values = zeros(1, length(x_values)); % 存储 PDP 值

for i = 1:length(x_values)
    % 复制原始数据，并将选定特征的值固定为当前值
    x_temp = x;
    x_temp(feature_index, :) = x_values(i);
    
    % 使用神经网络模型预测输出
    y_pred = net(x_temp);
    
    % 计算输出的平均值
    pdp_values(i) = mean(y_pred);
end

figure;
plot(x_values, pdp_values, '-o', 'LineWidth', 2);
xlabel(['Feature ', num2str(feature_index)]);
ylabel('Partial Dependence');
title('Partial Dependence Plot');
grid on;
