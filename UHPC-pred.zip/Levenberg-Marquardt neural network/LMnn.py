import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# 读取 Excel 文件
filename = "C:/Users/14579/Desktop/抗压强度数据1.xlsx"
data = pd.read_excel(filename).values

# 假设第一列到倒数第二列是输入数据，最后一列是目标数据
X = data[:, :-1]
y = data[:, -1]

# 归一化数据
scaler_X = MinMaxScaler()
scaler_y = MinMaxScaler()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y.reshape(-1, 1))

# 数据集划分
X_train, X_temp, y_train, y_temp = train_test_split(X_scaled, y_scaled, test_size=0.3, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

# 构建神经网络模型
model = Sequential([
    Dense(18, activation='relu', input_shape=(X.shape[1],)),
    Dense(1, activation='linear')
])

# 编译模型
model.compile(optimizer='adam', loss='mse')

# 训练模型
history = model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=100, batch_size=8, verbose=1)

# 预测并反归一化
y_train_pred = scaler_y.inverse_transform(model.predict(X_train))
y_val_pred = scaler_y.inverse_transform(model.predict(X_val))
y_test_pred = scaler_y.inverse_transform(model.predict(X_test))

y_train_true = scaler_y.inverse_transform(y_train)
y_val_true = scaler_y.inverse_transform(y_val)
y_test_true = scaler_y.inverse_transform(y_test)

# 计算 MSE 和 R^2
def calculate_metrics(y_true, y_pred):
    mse = np.mean((y_true - y_pred) ** 2)
    r2 = 1 - np.sum((y_true - y_pred) ** 2) / np.sum((y_true - np.mean(y_true)) ** 2)
    return mse, r2

mse_train, r2_train = calculate_metrics(y_train_true, y_train_pred)
mse_val, r2_val = calculate_metrics(y_val_true, y_val_pred)
mse_test, r2_test = calculate_metrics(y_test_true, y_test_pred)

print(f'Train MSE: {mse_train:.4f}, R2: {r2_train:.4f}')
print(f'Validation MSE: {mse_val:.4f}, R2: {r2_val:.4f}')
print(f'Test MSE: {mse_test:.4f}, R2: {r2_test:.4f}')

# 计算 a20 指数
def calculate_a20(y_true, y_pred):
    relative_error = np.abs((y_pred - y_true) / y_true)
    return np.mean(relative_error <= 0.2)

a20_train = calculate_a20(y_train_true, y_train_pred)
a20_val = calculate_a20(y_val_true, y_val_pred)
a20_test = calculate_a20(y_test_true, y_test_pred)

print(f'Train a20 Index: {a20_train:.4f}')
print(f'Validation a20 Index: {a20_val:.4f}')
print(f'Test a20 Index: {a20_test:.4f}')

# 可视化训练过程
plt.figure()
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('MSE Loss')
plt.legend()
plt.title('Training Process')
plt.show()

