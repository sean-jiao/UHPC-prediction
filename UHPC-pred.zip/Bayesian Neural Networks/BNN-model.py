import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import r2_score
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import MeanSquaredError
import optuna

# 1. 读取 Excel 文件
filename = r"C:\Users\14579\Desktop\抗压强度数据.xlsx"
data = pd.read_excel(filename)

# 2. 假设第一列到倒数第二列为输入，最后一列为目标
X = data.iloc[:, :-1].values  # shape (samples, features)
y = data.iloc[:, -1].values.reshape(-1, 1)  # shape (samples, 1)

# 3. 数据预处理：归一化到 [-1,1]
scaler_X = MinMaxScaler(feature_range=(-1, 1))
scaler_y = MinMaxScaler(feature_range=(-1, 1))
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y)

# 4. 划分数据集：70%训练，15%验证，15%测试
X_train, X_temp, y_train, y_temp = train_test_split(X_scaled, y_scaled, test_size=0.3, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)


# 5. 定义模型构建函数（供优化使用）
def build_model(hidden_size, learning_rate, dropout_rate=None):
    model = Sequential()
    model.add(Dense(hidden_size, activation='tanh', input_shape=(X.shape[1],)))
    if dropout_rate:
        model.add(Dropout(dropout_rate))
    model.add(Dense(1, activation='linear'))
    model.compile(optimizer=Adam(learning_rate=learning_rate), loss=MeanSquaredError())
    return model


# 6. 定义目标函数用于超参数优化
def objective(trial):
    # 超参数搜索范围
    hidden_size = trial.suggest_int('hidden_size', 5, 100)
    learning_rate = trial.suggest_loguniform('learning_rate', 1e-4, 1e-1)
    batch_size = trial.suggest_categorical('batch_size', [16, 32, 64])
    dropout_rate = trial.suggest_uniform('dropout_rate', 0.0, 0.5)

    # 构建并训练模型
    model = build_model(hidden_size, learning_rate, dropout_rate)
    early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    history = model.fit(X_train, y_train,
                        epochs=200,
                        batch_size=batch_size,
                        validation_data=(X_val, y_val),
                        callbacks=[early_stop],
                        verbose=0)

    # 评估验证集 MSE
    mse_val = model.evaluate(X_val, y_val, verbose=0)
    return mse_val


# 7. 执行超参数优化
study = optuna.create_study(direction='minimize')
study.optimize(objective, n_trials=50)  # 尝试 50 组参数组合
print("Best parameters:", study.best_params)
print("Best validation MSE:", study.best_value)

# 8. 使用最佳参数训练最终模型
best_params = study.best_params
final_model = build_model(best_params['hidden_size'], best_params['learning_rate'], best_params['dropout_rate'])
early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
history = final_model.fit(X_train, y_train,
                          epochs=200,
                          batch_size=best_params['batch_size'],
                          validation_data=(X_val, y_val),
                          callbacks=[early_stop],
                          verbose=1)

# 9. 测试模型并评估性能
y_train_pred = final_model.predict(X_train)
y_val_pred = final_model.predict(X_val)
y_test_pred = final_model.predict(X_test)

# 计算 MSE
mse_train = np.mean((y_train - y_train_pred) ** 2)
mse_val = np.mean((y_val - y_val_pred) ** 2)
mse_test = np.mean((y_test - y_test_pred) ** 2)

print("Train MSE:", mse_train)
print("Validation MSE:", mse_val)
print("Test MSE:", mse_test)

# 计算 R²（决定系数）
r2_train = r2_score(y_train, y_train_pred)
r2_val = r2_score(y_val, y_val_pred)
r2_test = r2_score(y_test, y_test_pred)

print("Train R2:", r2_train)
print("Validation R2:", r2_val)
print("Test R2:", r2_test)

# 10. 可视化训练过程
plt.figure(figsize=(8, 6))
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training and Validation Loss')
plt.legend()
plt.show()


# 11. 置换特征重要性分析函数
def permutation_feature_importance(model, X, y, baseline_mse):
    n_features = X.shape[1]
    importances = np.zeros(n_features)
    for i in range(n_features):
        X_permuted = X.copy()
        np.random.shuffle(X_permuted[:, i])
        y_pred = model.predict(X_permuted)
        mse_permuted = np.mean((y - y_pred) ** 2)
        importances[i] = mse_permuted - baseline_mse
    importances = importances / np.max(importances)
    return importances


# 计算特征重要性
baseline_mse = mse_test
feature_importance = permutation_feature_importance(final_model, X_test, y_test, baseline_mse)

# 12. 可视化特征重要性
plt.figure(figsize=(8, 6))
plt.barh(range(X.shape[1]), feature_importance)
plt.xlabel("Normalized Importance")
plt.ylabel("Feature Index")
plt.title("Permutation Feature Importance")
plt.show()