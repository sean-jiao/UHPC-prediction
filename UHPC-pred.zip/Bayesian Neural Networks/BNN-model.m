% 读取 Excel 文件
filename = "C:\Users\14579\Desktop\抗压强度数据.xlsx";  % Excel 文件名
data = readmatrix(filename);  % 读取整个表格数据

% 假设第一列是输入数据，最后一列是目标数据
x = data(:, 1:end-1)';  % 输入数据（转置）
t = data(:, end)';      % 目标数据（转置）

trainFcn = 'trainbr';  % Bayesian Regularization backpropagation.

% Create a Fitting Network
hiddenLayerSize = 20;
net = fitnet(hiddenLayerSize,trainFcn);

% Choose Input and Output Pre/Post-Processing Functions
% For a list of all processing functions type: help nnprocess
net.input.processFcns = {'removeconstantrows','mapminmax'};
net.output.processFcns = {'removeconstantrows','mapminmax'};

% Setup Division of Data for Training, Validation, Testing
% For a list of all data division functions type: help nndivision
net.divideFcn = 'dividerand';  % Divide data randomly
net.divideMode = 'sample';  % Divide up every sample
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;

% Choose a Performance Function
% For a list of all performance functions type: help nnperformance
net.performFcn = 'mse';  % 均方误差

% Choose Plot Functions
% For a list of all plot functions type: help nnplot
net.plotFcns = {'plotperform','plottrainstate','ploterrhist', ...
    'plotregression', 'plotfit'};

% Train the Network
[net,tr] = train(net,x,t);

% Test the Network
y = net(x);
e = gsubtract(t,y);
performance = perform(net,t,y)

% Recalculate Training, Validation and Test Performance
trainTargets = t .* tr.trainMask{1};
valTargets = t .* tr.valMask{1};
testTargets = t .* tr.testMask{1};
trainPerformance = perform(net,trainTargets,y)
valPerformance = perform(net,valTargets,y)
testPerformance = perform(net,testTargets,y)

% View the Network
view(net)

% Plots
% Uncomment these lines to enable various plots.
%figure, plotperform(tr)
%figure, plottrainstate(tr)
%figure, ploterrhist(e)
%figure, plotregression(t,y)
%figure, plotfit(net,x,t)

% Deployment
% Change the (false) values to (true) to enable the following code blocks.
% See the help for each generation function for more information.
if (false)
    % Generate MATLAB function for neural network for application
    % deployment in MATLAB scripts or with MATLAB Compiler and Builder
    % tools, or simply to examine the calculations your trained neural
    % network performs.
    genFunction(net,'myNeuralNetworkFunction');
    y = myNeuralNetworkFunction(x);
end
if (false)
    % Generate a matrix-only MATLAB function for neural network code
    % generation with MATLAB Coder tools.
    genFunction(net,'myNeuralNetworkFunction','MatrixOnly','yes');
    y = myNeuralNetworkFunction(x);
end
if (false)
    % Generate a Simulink diagram for simulation or deployment with.
    % Simulink Coder tools.
    gensim(net);
end


% Define the permutation feature importance function
function featureImportance = permutationFeatureImportance(net, x, t)
    % Get the original performance (MSE)
    yOriginal = net(x);
    originalPerformance = perform(net, t, yOriginal);
    
    % Number of features
    numFeatures = size(x, 1);
    
    % Initialize a vector to store feature importances
    featureImportance = zeros(numFeatures, 1);
    
    % Loop over each feature
    for i = 1:numFeatures
        % Make a copy of the original input data
        xPermuted = x;
        
        % Randomly permute the i-th feature
        xPermuted(i,:) = xPermuted(i,randperm(size(xPermuted, 2)));
        
        % Evaluate the performance of the network with the permuted feature
        yPermuted = net(xPermuted);
        permutedPerformance = perform(net, t, yPermuted);
        
        % Calculate the increase in error due to permuting the feature
        featureImportance(i) = permutedPerformance - originalPerformance;
    end
    
    % Normalize the feature importance by the original performance
    featureImportance = featureImportance / max(featureImportance);
    
    % Display the results as a horizontal bar chart
    figure;
    barh(featureImportance);  % Horizontal bar chart
    title('Permutation Feature Importance');
    xlabel('Importance');
    ylabel('Feature Index');
end

% Call the permutation feature importance function
featureImportance = permutationFeatureImportance(net, x, t);